# google-play-listing 主商店 Listing 草稿报告

生成时间：`2026-06-17T14:44:20Z`

## 总状态
- overall_status: `blocked`
- 证明模式：`executed`
- can_submit_google_play: `false`

## Listing 草稿输出
| Locale | Source | appName | shortDescription | fullDescription |
| --- | --- | --- | --- | --- |
| default | `app_identity_candidates` | Magazine Digest | NEED_HUMAN | NEED_HUMAN |

## 字段长度矩阵
| Locale | Field | Length | Limit | Status | Reason |
| --- | --- | --- | --- | --- | --- |
| default | `appName` | 15 | 30 | `pass` | 字段存在且长度合规。 |
| default | `shortDescription` | 0 | 80 | `blocked` | 字段缺失，需要提供真实 listing 文案。 |
| default | `fullDescription` | 0 | 4000 | `blocked` | 字段缺失，需要提供真实 listing 文案。 |

## Listing Gate 矩阵
| Gate | Status | 结论 |
| --- | --- | --- |
| `app_identity` | `pass` | 发现通用 app identity。 |
| `listing_metadata_source` | `blocked` | 未发现 listing JSON 或 fastlane metadata；只能生成 NEED_HUMAN 草稿。 |
| `listing_text_fields` | `blocked` | 存在缺失、占位或超长 listing 文案字段。 |
| `metadata_policy` | `pass` | 未发现 metadata policy 风险词。 |
| `preview_assets` | `blocked` | app icon、feature graphic 或 screenshots 缺失/不合规。 |
| `human_required_fields` | `blocked` | privacy policy URL、developer contact、category、content rating 或 target audience 仍需人工提供/确认。 |

## Preview Assets 状态
- `app_icon`：`blocked`；未发现 512x512、32-bit PNG、<=1024KB 的 app icon。
- `feature_graphic`：`blocked`；未发现 1024x500 JPEG 或 24-bit PNG feature graphic。
- `screenshots`：`blocked`；未发现至少 2 张 screenshot 候选。
- `video`：`optional_missing`；Promo video 是可选素材；当前未发现视频候选。

## Metadata Policy 风险
- status: `pass`
- 未发现误导、无关、过度格式化、排名、价格、促销或不合适 metadata 风险。

## 人类需要提供什么
- `privacy_policy_url`：`NEED_HUMAN`；status=`missing`；未在 listing metadata 中发现该字段。
- `developer_contact_email`：`NEED_HUMAN`；status=`missing`；未在 listing metadata 中发现该字段。
- `category`：`NEED_HUMAN`；status=`missing`；未在 listing metadata 中发现该字段。
- `content_rating`：`NEED_HUMAN`；status=`missing`；未在 listing metadata 中发现该字段。
- `target_audience`：`NEED_HUMAN`；status=`missing`；未在 listing metadata 中发现该字段。

## 阻塞项
- `gate:listing_metadata_source`：status=`blocked`；原因：未发现 listing JSON 或 fastlane metadata；只能生成 NEED_HUMAN 草稿。；解除：提供 Google Play listing JSON，或 fastlane metadata/android/<locale>/title.txt、short_description.txt、full_description.txt。
- `gate:listing_text_fields`：status=`blocked`；原因：存在缺失、占位或超长 listing 文案字段。；解除：补齐或修正 app title、short description、full description；确保长度分别 <= 30、<= 80、<= 4000。
- `gate:preview_assets`：status=`blocked`；原因：app icon、feature graphic 或 screenshots 缺失/不合规。；解除：提供 512x512 32-bit PNG app icon、1024x500 feature graphic、至少 2 张截图；video 可选。
- `gate:human_required_fields`：status=`blocked`；原因：privacy policy URL、developer contact、category、content rating 或 target audience 仍需人工提供/确认。；解除：人工提供并确认 privacy policy URL、developer contact、category、content rating 和 target audience。

## 总结
- 当前 Google Play 主商店 listing gate 状态：`blocked`。
- 阻塞 gate：listing_metadata_source, listing_text_fields, preview_assets, human_required_fields。
- 已通过 gate：app_identity, metadata_policy。
- 优先顺序：先提供真实 listing metadata；补齐并压缩 title/short/full description；补齐 icon、feature graphic 和 screenshots；补齐人工字段。
- 本报告只准备 listing draft 和阻塞证据，不提交 Google Play，不声明最终批准。
