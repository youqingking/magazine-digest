# Google Play 上架材料人工处理清单

- 生成时间：2026-06-17T16:07:30Z
- 总状态：blocked

| 归属 | 来源材料 | 处理项 | 原因 | 完成标准 |
| --- | --- | --- | --- | --- |
| 工程 | 工程发布门禁 | gate:build | 结构化输出 classification=compile_readiness_failed。 | 修复 build 命令报告的失败原因后，重新真实执行该 gate。 |
| 工程 | 工程发布门禁 | gate:typecheck | 未在现有 package scripts / README 命令中发现 typecheck 门禁命令。 | 在项目已有脚本体系中补齐 typecheck 命令，并真实执行该命令。 |
| 工程 | 工程发布门禁 | gate:smoke | 结构化输出 status=blocked。 | 修复 smoke 命令报告的失败原因后，重新真实执行该 gate。 |
| 隐私/法务/产品 | 隐私披露准备 | privacy_policy_url_missing | 未在扫描范围内发现隐私政策 URL。 | 提供公开可访问的隐私政策 URL，并确认内容覆盖当前 app、SDK、数据收集、共享和删除流程。 |
| 产品/运营 | 上架基础信息 | App 名称 | 发现多个产品名候选，需要人工确定最终上架名称和备用名。 | 确认唯一最终产品名；把其他候选名标为备用名或技术名。 |
| 产品/运营 | 上架基础信息 | 一句话定位 | 未发现一句话定位。 | 提供一句话定位，格式建议：为 [目标用户] 解决 [核心问题] 的 [产品类别]。 |
| 产品/运营 | 上架基础信息 | 目标用户 | 未发现目标用户。 | 提供目标用户段，例如学生、创作者、独立开发者、家庭用户等。 |
| 产品/运营 | 上架基础信息 | 账号系统 | 发现账号/登录能力信号，但没有证明 app 是否必须登录。 | 说明是否必须登录、哪些功能可游客使用、是否提供账号删除/注销入口。 |
| 产品/运营 | 上架基础信息 | 支持方式 | 未发现 support URL、email 或 FAQ。 | 提供可公开的 support URL、support email 或 FAQ/help center。 |
| 隐私/法务/产品 | Google Play Data safety | 加密传输 | 静态项目证据不能证明所有传输路径和第三方 SDK 均加密传输。 | 提供网络传输与第三方 SDK 传输是否加密的证明或人工确认。 |
| 隐私/法务/产品 | Google Play Data safety | 隐私政策 URL | 未发现可用于 Data safety 的隐私政策 URL。 | 提供公开可访问且覆盖当前 app 数据行为的隐私政策 URL。 |
| 隐私/法务/产品 | Google Play Data safety | 儿童/敏感数据风险 | 未发现足够证据确认是否面向儿童或处理敏感数据。 | 确认目标年龄、儿童/家庭政策和敏感数据处理范围。 |
| 隐私/法务/产品 | Google Play Data safety | 逐数据类型答案 | 发现 11 个数据类型候选；collected/shared/purpose/identity/tracking 需要人工逐项确认。 | 逐项确认每个数据类型是否收集、是否共享、用途、是否关联身份、是否用于 tracking、是否必需。 |
| 产品/运营/设计 | Google Play 主商店 listing | gate:listing_metadata_source | 未发现 listing JSON 或 fastlane metadata；只能生成 NEED_HUMAN 草稿。 | 提供 Google Play listing JSON，或 fastlane metadata/android/<locale>/title.txt、short_description.txt、full_description.txt。 |
| 产品/运营/设计 | Google Play 主商店 listing | gate:listing_text_fields | 存在缺失、占位或超长 listing 文案字段。 | 补齐或修正 app title、short description、full description；确保长度分别 <= 30、<= 80、<= 4000。 |
| 产品/运营/设计 | Google Play 主商店 listing | gate:preview_assets | app icon、feature graphic 或 screenshots 缺失/不合规。 | 提供 512x512 32-bit PNG app icon、1024x500 feature graphic、至少 2 张截图；video 可选。 |
| 产品/运营/设计 | Google Play 主商店 listing | gate:human_required_fields | privacy policy URL、developer contact、category、content rating 或 target audience 仍需人工提供/确认。 | 人工提供并确认 privacy policy URL、developer contact、category、content rating 和 target audience。 |
| 产品/运营/设计 | Google Play 主商店 listing | privacy_policy_url | 未在 listing metadata 中发现该字段。 | 补充并确认 privacy_policy_url。 |
| 产品/运营/设计 | Google Play 主商店 listing | developer_contact_email | 未在 listing metadata 中发现该字段。 | 补充并确认 developer_contact_email。 |
| 产品/运营/设计 | Google Play 主商店 listing | category | 未在 listing metadata 中发现该字段。 | 补充并确认 category。 |
| 产品/运营/设计 | Google Play 主商店 listing | content_rating | 未在 listing metadata 中发现该字段。 | 补充并确认 content_rating。 |
| 产品/运营/设计 | Google Play 主商店 listing | target_audience | 未在 listing metadata 中发现该字段。 | 补充并确认 target_audience。 |
| 产品/设计 | 截图 storyboard | release_gate_not_passed | release-build-agent 当前状态为 blocked；截图规划不能代表可提交素材。 | 先修复 build/typecheck/smoke 等 release blockers，再重新捕获截图。 |
| 产品/设计 | 截图 storyboard | raw_screenshots_not_captured | 尚未通过 screenshot-capture-agent 证明真实 raw screenshots。 | 使用生成的 screenshot-shot-list.json 重跑 screenshot-capture-agent，并确保目标 app 在前台。 |
| 产品/设计 | 截图 storyboard | privacy_or_target_audience_needs_human | 隐私、Data safety、目标年龄或敏感内容仍有人工确认项，公开截图文案需同步确认。 | 完成 privacy/data safety/target audience 人工审核后再批准公开截图。 |
| 工程/设计 | 真实截图捕获 | debug_container_needs_human | 当前目标 package 是 HBuilderX debug 容器，不能自动等同于最终 release app 体验。 | 人工确认 debug 容器画面可代表目标 app，或安装 release package 后重跑。 |
| 工程/设计 | 真实截图捕获 | target_app_not_foreground | 目标 package 未处于前台。foreground=com.google.android.apps.nexuslauncher target=io.dcloud.HBuilder | 手动打开目标 app/目标页面，或使用 --launch 后确认 app 能启动，再重跑。 |
| 工程/设计 | 真实截图捕获 | multi_shot_navigation_unverified | 上游 shot-list 包含多个 shot，但未指定 --shot-id 或 --navigation-verified；不能把当前屏幕重复写成多个 route 的截图证据。 | 每次使用 --shot-id 捕获一个 shot，或在自动/人工导航完成后显式传入 --navigation-verified。 |
| 工程/设计 | 真实截图捕获 | google_play_public_use_needs_human | 截图公开上架使用必须人工审核内容、裁切、安全区、商标和是否误导。 | 由 owner/design/legal 审核 raw 截图和最终商店图。 |
