# launch-info-collector 上架信息收集报告

生成时间：`2026-06-17T15:32:30Z`

## 总状态
- overall_status: `blocked`
- proof_mode: `parsed_repo_evidence`
- 输出目录：`play-store-launch/reports`

## Launch 信息矩阵
| 字段 | 状态 | 当前值/候选 | 证据 | 人类需要做什么 |
| --- | --- | --- | --- | --- |
| App 名称 | `conflict` | None | ev_0001, ev_0002, ev_0003, ev_0004, ev_0005, ev_0006 | 确认唯一最终产品名；把其他候选名标为备用名或技术名。 |
| 一句话定位 | `missing` | NEED_HUMAN | - | 提供一句话定位，格式建议：为 [目标用户] 解决 [核心问题] 的 [产品类别]。 |
| 核心功能 | `inferred` | 阅读与内容管理；内容发现与关注；订阅、权益与付费；通知与触达；账号与个人资料 | ev_0007, ev_0008, ev_0009, ev_0010, ev_0011 | 把候选功能改写并确认成 3-5 个主卖点，避免承诺不存在或未发布的功能。 |
| 目标用户 | `missing` | NEED_HUMAN | - | 提供目标用户段，例如学生、创作者、独立开发者、家庭用户等。 |
| 支持平台 | `inferred` | Android(observed)；iOS(inferred)；Web/H5(observed)；React Native/Expo(observed)；uni-app(observed) | ev_0014, ev_0015, ev_0016, ev_0017, ev_0018 | 确认哪些平台属于本次上架/发布范围，尤其是仅由框架能力推断的平台。 |
| 隐私相关 | `inferred` | {"data_categories": ["账号/个人资料", "设备/推送标识", "内容行为/阅读状态", "订阅/支付/权益", "活动/分析事件"], "third_party_sdk_candidates": ["expo", "uni_app"], "android_permiss... | ev_0019, ev_0020, ev_0021, ev_0022, ev_0023, ev_0024, ev_0025 | 补充并确认：实际收集的数据、是否关联身份、是否追踪、是否共享、第三方 SDK 用途、隐私政策 URL。 |
| 账号系统 | `needs_human` | {"account_signals_found": true, "must_login": "NEED_HUMAN"} | ev_0026 | 说明是否必须登录、哪些功能可游客使用、是否提供账号删除/注销入口。 |
| 订阅/内购 | `inferred` | {"monetization_signals_found": true, "has_iap_or_subscription": "LIKELY_YES"} | ev_0027 | 确认是否有 IAP、订阅、试用、价格、支付渠道，以及 Google Play Billing 合规路径。 |
| 支持方式 | `missing` | NEED_HUMAN | - | 提供可公开的 support URL、support email 或 FAQ/help center。 |
| 截图 demo 数据 | `inferred` | {"demo_data_signals_found": true, "example_sources": [{"source": "backend/adapters/fixture-repository.mjs", "matched": "fixtures?", "where": "path"... | ev_0028 | 确认截图所需示例用户、示例项目、示例结果，并保证不展示不存在的功能。 |

## App 名称候选
- 产品名候选：Magazine Digest, 高效阅读
- 备用/技术名候选：com.daowei2026.magazinedigest, magazine-digest, __UNI__005A993, 高效阅读

## 证据摘要
- `ev_0001` `app_name` from `app.json`：Magazine Digest
- `ev_0002` `app_identifier` from `app.json`：com.daowei2026.magazinedigest
- `ev_0003` `app_identifier` from `package.json`：magazine-digest
- `ev_0004` `alternate_names` from `package.json`：magazine-digest
- `ev_0005` `app_name` from `mobile/manifest.json`：高效阅读
- `ev_0006` `app_identifier` from `mobile/manifest.json`：__UNI__005A993
- `ev_0007` `core_features` from `admin/pages-generated/articles.generated.json, admin/pages-generated/publications.generated.json, backend/surfaces/content-detail.mjs, backend/surfaces/content-resume.mjs, backend/surfaces/save-for-later.mjs`：阅读与内容管理
- `ev_0008` `core_features` from `admin/pages-generated/user_follows.generated.json, backend/surfaces/follow-catalog.mjs, backend/surfaces/follow-toggle.mjs, backend/surfaces/home-discovery.mjs, backend/surfaces/search-content.mjs`：内容发现与关注
- `ev_0009` `core_features` from `admin/pages-generated/pricing_plans.generated.json, backend/surfaces/commercial-offer.mjs, backend/surfaces/entitlement-snapshot.mjs, backend/surfaces/pricing-preview.mjs, database/entitlements.schema.json`：订阅、权益与付费
- `ev_0010` `core_features` from `admin/pages-generated/notification_campaigns.generated.json, admin/pages-generated/notification_deliveries.generated.json, admin/pages-generated/notification_inbox.generated.json, admin/pages-generated/promo_campaigns.generated.json, admin/pages-generated/user_notification_prefs.generated.json`：通知与触达
- `ev_0011` `core_features` from `backend/surfaces/auth-refresh.mjs, backend/surfaces/auth-session.mjs, backend/surfaces/auth-signout.mjs, backend/surfaces/profile-benefits.mjs, database/user_product_profiles.schema.json`：账号与个人资料
- `ev_0012` `core_features` from `admin/pages-generated/publish_batches.generated.json, backend/surfaces/content-sync-delta.mjs, backend/surfaces/publish-batch-summary.mjs, database/publish_batches.schema.json, docs/SCHEMA_SYNC.md`：发布与同步流程
- `ev_0013` `core_features` from `admin/pages-generated/promo_campaigns.generated.json, admin/pages-generated/promo_codes.generated.json, admin/pages-generated/referrals.generated.json, admin/pages-generated/reward_ledger.generated.json, backend/surfaces/promo-preview.mjs`：激励与增长
- `ev_0014` `supported_platforms` from `app.json`：Android
- `ev_0015` `supported_platforms` from `app.json`：iOS
- `ev_0016` `supported_platforms` from `index.html`：Web/H5
- `ev_0017` `supported_platforms` from `package.json`：React Native/Expo
- `ev_0018` `supported_platforms` from `mobile/manifest.json`：uni-app
- 另有 10 条证据见 JSONL。

## 阻塞项
- `App 名称` status=`conflict`：发现多个产品名候选，需要人工确定最终上架名称和备用名。 解除方式：确认唯一最终产品名；把其他候选名标为备用名或技术名。
- `一句话定位` status=`missing`：未发现一句话定位。 解除方式：提供一句话定位，格式建议：为 [目标用户] 解决 [核心问题] 的 [产品类别]。
- `目标用户` status=`missing`：未发现目标用户。 解除方式：提供目标用户段，例如学生、创作者、独立开发者、家庭用户等。
- `账号系统` status=`needs_human`：发现账号/登录能力信号，但没有证明 app 是否必须登录。 解除方式：说明是否必须登录、哪些功能可游客使用、是否提供账号删除/注销入口。
- `支持方式` status=`missing`：未发现 support URL、email 或 FAQ。 解除方式：提供可公开的 support URL、support email 或 FAQ/help center。

## 总结
- 当前 launch-info-collector 总状态：`blocked`。
- 不能交给下游作为完整 source-of-truth：还有 5 个字段缺失、冲突或必须人工确认。
- 优先处理：App 名称：确认唯一最终产品名；把其他候选名标为备用名或技术名；一句话定位：提供一句话定位，格式建议：为 [目标用户] 解决 [核心问题] 的 [产品类别]；目标用户：提供目标用户段，例如学生、创作者、独立开发者、家庭用户等；账号系统：说明是否必须登录、哪些功能可游客使用、是否提供账号删除/注销入口；支持方式：提供可公开的 support URL、support email 或 FAQ/help center。
- 推断字段需要人工复核：core_features, supported_platforms, privacy, subscription_iap, screenshot_demo_data。
- 本报告只收集和归类 launch 信息，不执行任何发布动作。
