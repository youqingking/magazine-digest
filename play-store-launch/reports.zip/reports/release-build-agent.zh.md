# release-build-agent 工程门禁证明报告

生成时间：`2026-06-17T13:30:43Z`

## 总状态
- overall_status: `blocked`
- 证明模式：`executed`

## 本地工具准备
- `hbuilderx`：`ready`；cli=`D:\HBuilderX\cli.exe`
- `android_emulator`：`ready`；adb=`C:\Users\Administrator\AppData\Local\Android\Sdk\platform-tools\adb.EXE`；emulator=`C:\Users\Administrator\AppData\Local\Android\Sdk\emulator\emulator.EXE`；avd=`FactLock_API_35`；serial=`emulator-5554`

## 工程门禁矩阵
| Gate | Status | 证明结论 |
| --- | --- | --- |
| `build` | `fail` | 结构化输出 classification=compile_readiness_failed。 |
| `typecheck` | `script_missing` | 未发现项目已有命令，不能证明。 |
| `smoke` | `blocked` | 结构化输出 status=blocked。 |
| `preflight` | `pass` | 已由真实执行的项目命令证明通过。 |

## 命令执行证据
### `build`
- `build:mobile` / `fail` / exit=0 / 结构化输出 classification=compile_readiness_failed。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/bootstrap/build-mobile.ps1`；实际命令：`npm.cmd run build:mobile`
  - parsed: `{"classification": "compile_readiness_failed", "compile_success": false, "compile_readiness_passed": false, "real_compile_attempted": false, "findings": {"cross_root_imports": ["mobile/pages/feed/index.vue", "mobile/pages/search/index.vue"], "relevant_node_only_references": [{"file": "mobile/fixtures/runtime/scenarios/data1c_barrons_09022026.bundle.json", "pattern": "Buffer"}, {"file": "mobile/fixtures/runtime/scenarios/data1c_three_release_mixed_preview.bundle.json", "pattern": "Buffer"}, {"file": "mobile/fixtures/runtime/source-registry.generated.json", "pattern": "Buffer"}, {"file": "mobile/fixtures/runtime/source-registry.js", "pattern": "Buffer"}]}}`
  - 需要处理：
    - 修复移动端跨根引用：mobile/pages/feed/index.vue, mobile/pages/search/index.vue。
    - 移除或替换移动端运行路径里的 Node-only API 引用：mobile/fixtures/runtime/scenarios/data1c_barrons_09022026.bundle.json, mobile/fixtures/runtime/scenarios/data1c_three_release_mixed_preview.bundle.json, mobile/fixtures/runtime/source-registry.generated.json, mobile/fixtures/runtime/source-registry.js。
    - 修复后重新运行 `npm.cmd run build:mobile`，直到 `compile_success=true` 或真实编译通过。
### `typecheck`
- `script_missing`：未在现有 package scripts / README 命令中发现 typecheck 门禁命令。
### `smoke`
- `smoke` / `fail` / exit=0 / 结构化输出 mobile_status=null，不能证明移动端 smoke。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/bootstrap/smoke-stage-c.ps1`；实际命令：`npm.cmd run smoke`
  - parsed: `{"mobile_status": null}`
  - 需要处理：
    - 通用 smoke 没有覆盖移动端；必须依赖移动端专用 smoke 命令证明 app smoke。
- `smoke:stage-ui35-h5` / `blocked` / exit=0 / 结构化输出 status=blocked。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/bootstrap/smoke-stage-ui35-h5.ps1`；实际命令：`npm.cmd run smoke:stage-ui35-h5`
  - parsed: `{"status": "blocked", "blocking_reason": "HBUILDERX_WEB_BUILD_MISSING", "build_dir": "C:\\Users\\Administrator\\.codex\\worktrees\\66ef\\magazine-digest\\mobile\\unpackage\\dist\\build\\web"}`
  - 需要处理：
    - H5/Web smoke 需要构建产物，但目录不存在或为空：`C:\Users\Administrator\.codex\worktrees\66ef\magazine-digest\mobile\unpackage\dist\build\web`。
    - 先用 HBuilderX 对 `mobile/` 生成 H5/Web build，或补充一个项目已有脚本来生成该目录；完成后重跑 `npm.cmd run smoke:stage-ui35-h5` 和 `npm.cmd run smoke:h0_5-h5`。
- `smoke:h0_5-h5` / `blocked` / exit=0 / 结构化输出 status=blocked。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/bootstrap/smoke-h0_5-h5.ps1`；实际命令：`npm.cmd run smoke:h0_5-h5`
  - parsed: `{"status": "blocked", "blocking_reason": "HBUILDERX_WEB_BUILD_MISSING", "build_dir": "C:\\Users\\Administrator\\.codex\\worktrees\\66ef\\magazine-digest\\mobile\\unpackage\\dist\\build\\web"}`
  - 需要处理：
    - H5/Web smoke 需要构建产物，但目录不存在或为空：`C:\Users\Administrator\.codex\worktrees\66ef\magazine-digest\mobile\unpackage\dist\build\web`。
    - 先用 HBuilderX 对 `mobile/` 生成 H5/Web build，或补充一个项目已有脚本来生成该目录；完成后重跑 `npm.cmd run smoke:stage-ui35-h5` 和 `npm.cmd run smoke:h0_5-h5`。
- `smoke:h0_5-hbuilderx` / `pass` / exit=0 / 结构化输出 status=ok。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/bootstrap/smoke-h0_5-hbuilderx.ps1`；实际命令：`npm.cmd run smoke:h0_5-hbuilderx`
  - parsed: `{"status": "ok", "blocking_reason": "", "layer": "hbuilderx_android_compile", "compile_succeeded": true}`
- `smoke:h0_5-android` / `blocked` / exit=0 / 结构化输出 status=blocked。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/bootstrap/smoke-h0_5-android.ps1`；实际命令：`npm.cmd run smoke:h0_5-android`
  - parsed: `{"status": "blocked", "blocking_reason": "ANDROID_PACKAGE_UNRESOLVED", "layer": "android_device_smoke", "connected_devices": ["emulator-5554"], "detected_packages": ["io.dcloud.HBuilder", "com.factlock.os"]}`
  - 需要处理：
    - ADB 已有设备，但检测到多个第三方包：io.dcloud.HBuilder, com.factlock.os，脚本不能安全猜测哪个是目标 app。
    - 需要安装/确认目标 app 包名，并在重跑时提供 `H0_5_ANDROID_PACKAGE=<包名>`；如果 monkey 无法启动，还需要提供 `H0_5_ANDROID_ACTIVITY=<Activity>`。
- `smoke:h0_5-android-ui` / `fail` / exit=124 / 命令超时，未能形成通过证据。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/bootstrap/smoke-h0_5-android-ui.ps1`；实际命令：`npm.cmd run smoke:h0_5-android-ui`
  - parsed: `{"status": "blocked", "blocking_reason": "HBUILDERX_APP_LAUNCH_TIMEOUT", "layer": "android_device_ui_smoke", "connected_devices": ["emulator-5554"], "detected_packages": ["io.dcloud.HBuilder", "com.factlock.os"], "package_name": "io.dcloud.HBuilder", "hbuilderx_stdout_tail": ["20:43:52.066 HBuilderX Version: 5.07", "20:43:52.820 项目 mobile 开始编译", "20:43:53.195 uniCloud本地调试服务启动失败：当前项目未关联uniCloud服务空间，请调整后重新运行uni-app项目", "20:43:54.051 5.07", "20:43:54.053 请注意运行模式下，因日志输出、sourcemap以及未压缩源码等原因，性能和包体积，均不及发行模式。", "20:43:54.179 正在编译中...", "20:43:54.181 编译会生成大量临时文件，杀毒软件监控时会影响编译速度，并造成CPU升高。推荐把项目目录添加到杀毒软件的监控排除名单中。[添加] [帮助]", "20:43:54.634 \u001b[31m​Browserslist: caniuse-lite is outdated. Please run:\u001b[39m", "20:43:54.638 \u001b[31m  npx update-browserslist-db@latest\u001b[39m", "20:43:54.640 \u001b[31m  Why you should do it regularly: https://github.com/browserslist/update-db#readme​\u001b[39m", "20:43:58.871 \u001b[31mpages.json condition['list'][current]['path']: pages/auth-test/index 需在 pages 数组中\u001b[39m", "20:43:58.905 \u001b[31m已停止运行...\u001b[39m"]}`
  - 需要处理：
    - HBuilderX 日志显示目标自动化页面未注册：`pages/auth-test/index 需在 pages 数组中`。
    - `mobile/pages/auth-test/index.vue` 存在，但 `mobile/pages.json` 没有注册该 page；需要把 `pages/auth-test/index` 加入 `pages` 数组，或修改 smoke 脚本使用已注册页面。
    - 修复页面注册/启动目标后，重跑 `npm.cmd run smoke:h0_5-android-ui`；如果仍超时，再延长该命令 timeout 并检查 HBuilderX stdout/stderr tail。
### `preflight`
- `preflight` / `pass` / exit=0 / 退出码和结构化输出未发现失败信号。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/harness/preflight.ps1`；实际命令：`npm.cmd run preflight`
- `validate:preflight` / `pass` / exit=0 / 结构化输出 passed=true。
  - 来源：`package.json`；脚本内容：`powershell -ExecutionPolicy Bypass -File scripts/validate/preflight.ps1`；实际命令：`npm.cmd run validate:preflight`
  - parsed: `{"result": {"missing_count": 0, "passed": true}}`

## 诊断与修复计划
### `build`
- 命令：`npm.cmd run build:mobile`
  - 失败类型：`fail`。
  - 直接原因：结构化输出 classification=compile_readiness_failed。
  - 怎么修改：
    - 修复移动端跨根引用：mobile/pages/feed/index.vue, mobile/pages/search/index.vue。
    - 移除或替换移动端运行路径里的 Node-only API 引用：mobile/fixtures/runtime/scenarios/data1c_barrons_09022026.bundle.json, mobile/fixtures/runtime/scenarios/data1c_three_release_mixed_preview.bundle.json, mobile/fixtures/runtime/source-registry.generated.json, mobile/fixtures/runtime/source-registry.js。
    - 修复后重新运行 `npm.cmd run build:mobile`，直到 `compile_success=true` 或真实编译通过。

### `typecheck`
- 失败类型：`script_missing`。
- 直接原因：未在现有 package scripts / README 命令中发现 typecheck 门禁命令。
- 需要人类决定：项目应该使用 TypeScript 类型检查、Vue/uni-app 类型检查，还是现有 JS 项目暂不支持类型检查。
- 需要修改：在现有 `package.json` scripts 中补齐真实 `typecheck` 命令，不能用 `verify` 或 `preflight` 冒充。
- 重跑命令：补齐后运行新的 `npm.cmd run typecheck` 或等价现有脚本。

### `smoke`
- 命令：`npm.cmd run smoke`
  - 失败类型：`fail`。
  - 直接原因：结构化输出 mobile_status=null，不能证明移动端 smoke。
  - 怎么修改：
    - 通用 smoke 没有覆盖移动端；必须依赖移动端专用 smoke 命令证明 app smoke。
- 命令：`npm.cmd run smoke:stage-ui35-h5`
  - 失败类型：`blocked`。
  - 直接原因：结构化输出 status=blocked。
  - 怎么修改：
    - H5/Web smoke 需要构建产物，但目录不存在或为空：`C:\Users\Administrator\.codex\worktrees\66ef\magazine-digest\mobile\unpackage\dist\build\web`。
    - 先用 HBuilderX 对 `mobile/` 生成 H5/Web build，或补充一个项目已有脚本来生成该目录；完成后重跑 `npm.cmd run smoke:stage-ui35-h5` 和 `npm.cmd run smoke:h0_5-h5`。
- 命令：`npm.cmd run smoke:h0_5-h5`
  - 失败类型：`blocked`。
  - 直接原因：结构化输出 status=blocked。
  - 怎么修改：
    - H5/Web smoke 需要构建产物，但目录不存在或为空：`C:\Users\Administrator\.codex\worktrees\66ef\magazine-digest\mobile\unpackage\dist\build\web`。
    - 先用 HBuilderX 对 `mobile/` 生成 H5/Web build，或补充一个项目已有脚本来生成该目录；完成后重跑 `npm.cmd run smoke:stage-ui35-h5` 和 `npm.cmd run smoke:h0_5-h5`。
- 命令：`npm.cmd run smoke:h0_5-android`
  - 失败类型：`blocked`。
  - 直接原因：结构化输出 status=blocked。
  - 怎么修改：
    - ADB 已有设备，但检测到多个第三方包：io.dcloud.HBuilder, com.factlock.os，脚本不能安全猜测哪个是目标 app。
    - 需要安装/确认目标 app 包名，并在重跑时提供 `H0_5_ANDROID_PACKAGE=<包名>`；如果 monkey 无法启动，还需要提供 `H0_5_ANDROID_ACTIVITY=<Activity>`。
- 命令：`npm.cmd run smoke:h0_5-android-ui`
  - 失败类型：`fail`。
  - 直接原因：命令超时，未能形成通过证据。
  - 怎么修改：
    - HBuilderX 日志显示目标自动化页面未注册：`pages/auth-test/index 需在 pages 数组中`。
    - `mobile/pages/auth-test/index.vue` 存在，但 `mobile/pages.json` 没有注册该 page；需要把 `pages/auth-test/index` 加入 `pages` 数组，或修改 smoke 脚本使用已注册页面。
    - 修复页面注册/启动目标后，重跑 `npm.cmd run smoke:h0_5-android-ui`；如果仍超时，再延长该命令 timeout 并检查 HBuilderX stdout/stderr tail。

## 阻塞项
- `gate:build`：status=`fail`；原因：结构化输出 classification=compile_readiness_failed。；解除：修复 build 命令报告的失败原因后，重新真实执行该 gate。
- `gate:typecheck`：status=`script_missing`；原因：未在现有 package scripts / README 命令中发现 typecheck 门禁命令。；解除：在项目已有脚本体系中补齐 typecheck 命令，并真实执行该命令。
- `gate:smoke`：status=`blocked`；原因：结构化输出 status=blocked。；解除：修复 smoke 命令报告的失败原因后，重新真实执行该 gate。

## 总结
- 当前不能证明 app 通过发布前工程门禁；未通过 gate：build, typecheck, smoke。
- 本地工具已自动准备成功：hbuilderx, android_emulator；剩余阻塞来自项目命令输出本身。
- 已通过 gate：preflight。
- 优先顺序：修复 `build` 报告的构建/编译阻塞；补齐真实 `typecheck` 命令并执行通过；修复移动端 `smoke` 的 HBuilderX/H5/Android 设备阻塞并重跑。
